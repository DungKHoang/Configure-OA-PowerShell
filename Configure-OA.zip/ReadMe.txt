Configure-OA is a PowerShell script that leverages the HPE OA cmdlets to automate configuration of settings in OA including:
�	Alert Mail
�	Enclosure Bay IP Addresses (EBIPA)
�	LDAP Authentication
�	SNMP Settings/ SNMP User / SNMP Traps

Read the companion Word document for details

